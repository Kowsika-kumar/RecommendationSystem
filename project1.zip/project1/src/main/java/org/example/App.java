package org.example.App;

import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;

import java.io.File;
import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        try {
            // Step 1: Load user-item rating data from CSV
            DataModel model = new FileDataModel(new File("data.csv")); // Ensure this file is in the root

            // Step 2: Define user similarity metric (Pearson)
            UserSimilarity similarity = new PearsonCorrelationSimilarity(model);

            // Step 3: Define neighborhood (2 nearest users)
            UserNeighborhood neighborhood = new NearestNUserNeighborhood(2, similarity, model);

            // Step 4: Create the recommender system
            Recommender recommender = new GenericUserBasedRecommender(model, neighborhood, similarity);

            // Step 5: Get user input for ID and number of recommendations
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter user ID: ");
            int userId = sc.nextInt();
            System.out.print("Enter number of recommendations: ");
            int numRecommendations = sc.nextInt();

            // Step 6: Get recommendations
            List<RecommendedItem> recommendations = recommender.recommend(userId, numRecommendations);

            // Step 7: Display the recommended items
            if (recommendations.isEmpty()) {
                System.out.println("No recommendations found for user " + userId);
            } else {
                System.out.println("\nRecommended items for user " + userId + ":");
                for (RecommendedItem recommendation : recommendations) {
                    System.out.println("Item ID: " + recommendation.getItemID() +
                            " (Score: " + recommendation.getValue() + ")");
                }
            }

        } catch (Exception e) {
            System.err.println("Error running recommendation system: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
